package com.example.fbi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText emailaddress;
    private  EditText userpassword;
    private Button loginbutton;
    private String baseurl="http://devapi.talentaccurate.com/cview/login/json?username=";
    private  String middle="&password=";
    private String apivalue="&apikey=wf2537572d6f7b795a713c5e6w";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        emailaddress=(EditText) findViewById(R.id.email);
        userpassword=(EditText) findViewById(R.id.password);
        loginbutton=(Button) findViewById(R.id.login);

        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String myurl=baseurl+emailaddress.getText().toString()+middle+userpassword.getText().toString()+apivalue;
                Log.i("myurl","myurl"+myurl);

                Intent newintent= new Intent(MainActivity.this,profileavtivity.class);
                startActivity(newintent);
            }
        });
    }
}

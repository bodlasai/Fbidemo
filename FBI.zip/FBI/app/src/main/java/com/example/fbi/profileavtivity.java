package com.example.fbi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class profileavtivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profileavtivity);
    }
}
